rm responses_to_reviewers.pdf
texi2pdf -b responses_to_reviewers.tex
open responses_to_reviewers.pdf
